package model;

import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            
            System.setOut(new java.io.PrintStream(System.out, true, "UTF-8"));

            PessoaFisicaRepo pessoaFisicaRepo = new PessoaFisicaRepo();
            PessoaJuridicaRepo pessoaJuridicaRepo = new PessoaJuridicaRepo();
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("\n=== Cadastro de Pessoas ===");
                System.out.println("1. Incluir");
                System.out.println("2. Alterar");
                System.out.println("3. Excluir");
                System.out.println("4. Exibir pelo ID");
                System.out.println("5. Exibir todos");
                System.out.println("6. Salvar dados");
                System.out.println("7. Recuperar dados");
                System.out.println("0. Sair");
                System.out.print("Selecione uma opção: ");
                int opcao = scanner.nextInt();
                scanner.nextLine(); // Limpa o buffer

                switch (opcao) {
                    case 1 -> {
                        System.out.println("1. Pessoa Física");
                        System.out.println("2. Pessoa Jurídica");
                        System.out.print("Escolha o tipo: ");
                        int tipo = scanner.nextInt();
                        scanner.nextLine(); // Limpa o buffer

                        if (tipo == 1) {
                            System.out.print("ID: ");
                            int id = scanner.nextInt();
                            scanner.nextLine();
                            System.out.print("Nome: ");
                            String nome = scanner.nextLine();
                            System.out.print("CPF: ");
                            String cpf = scanner.nextLine();
                            System.out.print("Idade: ");
                            int idade = scanner.nextInt();
                            scanner.nextLine();
                            pessoaFisicaRepo.inserir(new PessoaFisica(id, nome, cpf, idade));
                        } else if (tipo == 2) {
                            System.out.print("ID: ");
                            int id = scanner.nextInt();
                            scanner.nextLine();
                            System.out.print("Nome: ");
                            String nome = scanner.nextLine();
                            System.out.print("CNPJ: ");
                            String cnpj = scanner.nextLine();
                            pessoaJuridicaRepo.inserir(new PessoaJuridica(id, nome, cnpj));
                        } else {
                            System.out.println("Opção inválida!");
                        }
                    }
                    case 2 -> {
                        // Similar à inclusão, mas altera o objeto no repositório.
                        System.out.println("Funcionalidade de alteração ainda não implementada.");
                    }
                    case 3 -> {
                        System.out.print("ID da pessoa a excluir: ");
                        int id = scanner.nextInt();
                        scanner.nextLine();
                        pessoaFisicaRepo.excluir(id);
                        pessoaJuridicaRepo.excluir(id);
                    }
                    case 4 -> {
                        System.out.print("ID da pessoa a exibir: ");
                        int id = scanner.nextInt();
                        scanner.nextLine();
                        PessoaFisica pf = pessoaFisicaRepo.obter(id);
                        if (pf != null) {
                            pf.exibir();
                        } else {
                            PessoaJuridica pj = pessoaJuridicaRepo.obter(id);
                            if (pj != null) {
                                pj.exibir();
                            } else {
                                System.out.println("Pessoa não encontrada.");
                            }
                        }
                    }
                    case 5 -> {
                        System.out.println("\nPessoas Físicas:");
                        for (PessoaFisica pf : pessoaFisicaRepo.obterTodos()) {
                            pf.exibir();
                        }
                        System.out.println("\nPessoas Jurídicas:");
                        for (PessoaJuridica pj : pessoaJuridicaRepo.obterTodos()) {
                            pj.exibir();
                        }
                    }
                    case 6 -> {
                        String arquivoPF = "pessoas_fisicas.dat";
                        String arquivoPJ = "pessoas_juridicas.dat";
                        pessoaFisicaRepo.persistir(arquivoPF);
                        pessoaJuridicaRepo.persistir(arquivoPJ);
                        System.out.println("Dados salvos com sucesso.");
                    }
                    case 7 -> {
                        String arquivoPF = "pessoas_fisicas.dat";
                        String arquivoPJ = "pessoas_juridicas.dat";
                        pessoaFisicaRepo.recuperar(arquivoPF);
                        pessoaJuridicaRepo.recuperar(arquivoPJ);
                        System.out.println("Dados recuperados com sucesso.");
                    }
                    case 0 -> {
                        System.out.println("Encerrando o programa...");
                        return;
                    }
                    default -> System.out.println("Opção inválida!");
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Erro: " + e.getMessage());
        }
    }
}
